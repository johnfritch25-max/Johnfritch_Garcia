﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CRUD_kay_sir_Cabrera
{
    public partial class Form2: Form
    {
        private string mySqlCon = "server=localhost;user=root;database=sample;password=garcia@2531";

        public Form2()
        {
            InitializeComponent();
            LoadUsers();
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.MultiSelect = false;
            dataGridView1.CellClick += dataGridView1_CellContentClick;
        }

        private void btnLogin2_Click(object sender, EventArgs e)
        {
            string username = txtUsername2.Text.Trim();
            string age = txtAge.Text.Trim();
            string email = txtEmail.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and Password are required!");
                return;
            }

            using (var conn = new MySqlConnection(mySqlCon))
            {
                try
                {
                    conn.Open();
                    string query = "INSERT INTO sampledb (name, age, email, password) VALUES (@name, @age, @email, @password)";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@name", username);
                        cmd.Parameters.AddWithValue("@age", age);
                        cmd.Parameters.AddWithValue("@email", email);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.ExecuteNonQuery();
                    }

                    MessageBox.Show("Login successfully!");
                    LoadUsers(); // ✅ refresh the DataGridView
                    return;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            LoadUsers();
        }

        private void LoadUsers()
        {
            using (var conn = new MySqlConnection(mySqlCon))
            {
                try
                {
                    conn.Open();
                    string query = "SELECT id, name, password, email, age FROM sampledb";
                    using (var adapter = new MySqlDataAdapter(query, conn))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);
                        dataGridView1.DataSource = dt;
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please select a user to update.");
                return;
            }

            int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["id"].Value);
            string username = txtUsername2.Text.Trim();
            string password = txtPassword.Text.Trim();
            string email = txtEmail.Text.Trim();
            string age = txtAge.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password.");
                return;
            }

            using (var conn = new MySqlConnection(mySqlCon))
            {
                try
                {
                    conn.Open();
                    string query = "UPDATE sampledb SET name=@name, password=@password, email=@email, age=@age WHERE id=@id";
                    using (var cmd = new MySqlCommand(query, conn))
                    {
                        cmd.Parameters.AddWithValue("@name", username);
                        cmd.Parameters.AddWithValue("@password", password);
                        cmd.Parameters.AddWithValue("@email", email);
                        cmd.Parameters.AddWithValue("@age", age);
                        cmd.Parameters.AddWithValue("@id", id);

                        int rows = cmd.ExecuteNonQuery();
                        if (rows > 0)
                        {
                            MessageBox.Show("User updated successfully.");
                            LoadUsers();
                        }
                        else
                        {
                            MessageBox.Show("Update failed.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            {
                if (dataGridView1.SelectedRows.Count == 0)
                {
                    MessageBox.Show("Please select a user to delete.");
                    return;
                }

                int id = Convert.ToInt32(dataGridView1.SelectedRows[0].Cells["id"].Value);

                using (var conn = new MySqlConnection(mySqlCon))
                {
                    try
                    {
                        conn.Open();
                        string query = "DELETE FROM sampledb WHERE id=@id";
                        using (var cmd = new MySqlCommand(query, conn))
                        {
                            cmd.Parameters.AddWithValue("@id", id);

                            int rows = cmd.ExecuteNonQuery();
                            if (rows > 0)
                            {
                                MessageBox.Show("User deleted successfully.");
                                LoadUsers();
                            }
                            else
                            {
                                MessageBox.Show("Delete failed.");
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                txtUsername2.Text = dataGridView1.SelectedRows[0].Cells["name"].Value.ToString();
                txtPassword.Text = dataGridView1.SelectedRows[0].Cells["password"].Value.ToString();
                txtEmail.Text = dataGridView1.SelectedRows[0].Cells["email"].Value.ToString();
                txtAge.Text = dataGridView1.SelectedRows[0].Cells["age"].Value.ToString();
            }
        }
    }
}

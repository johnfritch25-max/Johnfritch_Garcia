﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace CRUD_kay_sir_Cabrera
{
    public partial class Form1 : Form
    {
        private string mySqlCon = "server=localhost;user=root;database=sample;password=garcia@2531";
        public Form1()
        {
            InitializeComponent();
            TestDatabaseConnection();
        }
        private void TestDatabaseConnection()
        {
            using (var mySqlConnection = new MySqlConnection(mySqlCon))
            {
                try
                {
                    mySqlConnection.Open();
                    MessageBox.Show("Connection Successful");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Connection Failed: " + ex.Message);
                }
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();
           

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both username and password.");
                return;
            }

            using (var mySqlConnection = new MySqlConnection(mySqlCon))
            {
                try
                {
                    mySqlConnection.Open();
                    string query = "SELECT COUNT(*) FROM sampledb WHERE name=@name AND password=@password";
                    using (var cmd = new MySqlCommand(query, mySqlConnection))
                    {
                        cmd.Parameters.AddWithValue("@name", username);
                        cmd.Parameters.AddWithValue("@password", password);
                        

                        int count = Convert.ToInt32(cmd.ExecuteScalar());
                        if (count > 0)
                        {
                            MessageBox.Show("Login Successful!");
                            // Optionally, open another form or proceed
                        }
                        else
                        {
                            MessageBox.Show("Invalid username or password.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }

        }

        private void btnRegister_Click(object sender, EventArgs e)
        {
            Form2 registerForm = new Form2();
            registerForm.Show();
            this.Hide();
        }
    }
}
